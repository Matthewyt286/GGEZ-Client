package me.GGEZ.module;

import java.util.ArrayList;
import java.util.List;

import me.GGEZ.GGEZ;
import me.GGEZ.module.combat.*;
import me.GGEZ.module.movement.*;
import me.GGEZ.module.player.*;
import me.GGEZ.module.render.*;
import me.GGEZ.module.fun.*;
import me.GGEZ.module.misc.*;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class ModuleManager {

	private static ArrayList<Module> mods;

	public ModuleManager() {
		mods = new ArrayList<Module>();
		newMod(new TabGui());

		// COMBAT
		newMod(new Aimbot());
		newMod(new AntiFire());
		newMod(new FastBow());
		newMod(new KillAura2());
		newMod(new KillAuraLegit());
		newMod(new Velocity());
		newMod(new AutoClicker());

		// MOVEMENT
		newMod(new AutoSprint());
		newMod(new Flight());
		newMod(new AutoWalk());
		newMod(new Freecam());
		newMod(new Glide());
		newMod(new Jetpack());
		newMod(new NoFall());
		newMod(new Sneak());
		newMod(new Speed());
		newMod(new Step());
		newMod(new Scaffold());
		newMod(new BHop());
		newMod(new InvMove());
		newMod(new NoVoid());
		newMod(new LongJump());

		// PLAYER

		newMod(new AutoRespawn());
		newMod(new FastPlace());
		newMod(new InvManager());
		newMod(new Eagle());
		newMod(new AntiWeb());
		newMod(new Spammer());
		
		// RENDER
		newMod(new ClickGui());
		newMod(new ESPPlayer());
		newMod(new FullBright());
		newMod(new TracerPlayer());
		newMod(new BlockAnimations());
		newMod(new NoHurtCam());
		newMod(new KeyStrokes());

		// EXPLOIT

		// FUN
		newMod(new FakeLag());

		// GHOST

		// UTILITY

		// MISC
		newMod(new Timer());
		newMod(new Disabler());
		newMod(new Sound());
		newMod(new ChestStealer());
		
	}

	public static List<Module> getModulesbyCategory(Category c) {
		List<Module> modules = new ArrayList<Module>();

		for (Module m : GGEZ.instance.moduleManager.getModules()) {
			if (m.category == c)
				modules.add(m);
		}
		return modules;
	}

	public static void newMod(Module m) {
		mods.add(m);
	}

	public static ArrayList<Module> getModules() {
		return mods;
	}

	public static void onUpdate() {
		for (Module m : mods) {
			m.onUpdate();
		}
	}

	public static void onRender() {
		for (Module m : mods) {
			m.onRender();
		}
	}

	public static void onKey(int k) {
		for (Module m : mods) {
			if (m.getKey() == k) {
				m.toggle();
			}
		}
	}
	
	public static void addChatMessage(String message) {
		message = "\u00A75" + GGEZ.name + "\2477: " + message;
		
		Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(message));
	}

}
