package me.GGEZ.module.misc;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class Timer extends Module{

	public Timer() {
		super("Timer", 0, Category.MISC);
	}
	
	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("Timer Speed", this, 1, 0, 20, false));
	}
	
	public void onUpdate() {
	}
	
	public void onEnable() {
		if(GGEZ.instance.settingsManager.getSettingByName("Timer Speed").getValDouble() != 0.0) {
			mc.timer.timerSpeed = (float) (GGEZ.instance.settingsManager.getSettingByName("Timer Speed").getValDouble());
		}else {
			GGEZ.instance.moduleManager.addChatMessage("Timer speed could not be ZERO!");
		}
	}
	
	public void onDisable() {
		mc.timer.timerSpeed = 1f;
	}

}
