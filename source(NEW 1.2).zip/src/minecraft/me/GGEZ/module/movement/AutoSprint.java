package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class AutoSprint extends Module{

	public AutoSprint() {
		super("AutoSprint", 0, Category.MOVEMENT);
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			mc.thePlayer.setSprinting(true);
		}
	}
	
	@Override
	public void onDisable() {
		mc.thePlayer.setSprinting(false);
		super.onDisable();
	}

}
