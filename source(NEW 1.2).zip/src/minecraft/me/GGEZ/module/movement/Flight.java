package me.GGEZ.module.movement;

import java.util.ArrayList;
import java.util.Timer;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.Invoker;
import me.GGEZ.utils.TimerUtils;
import me.GGEZ.utils.Wrapper;
import net.minecraft.block.BlockAir;
import net.minecraft.block.material.Material;
import net.minecraft.util.BlockPos;

public class Flight extends Module{
	
	private TimerUtils timer = new TimerUtils();
	
	protected Timer time;
	
	double startY = 0;
	
	boolean singledamage;
	boolean singledamage1;
	
	public static float flyHackSpeed = 0.1f;
	float speed = (float) GGEZ.instance.settingsManager.getSettingByName("github1 Speed").getValDouble();
	
	public boolean damaged;
	
		public Flight() {
			super("Flight", Keyboard.KEY_G, Category.MOVEMENT);
		}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<>();
        options.add("Vanilla");
        options.add("Hypixel");
        options.add("CubeCraft");
        options.add("github1");
        options.add("BattleAsya");
        options.add("ACFly1");
        options.add("ACFly2");
        options.add("ACFly3");
        options.add("MineLand");
        options.add("McCentral");
        options.add("ACENTRAMC");
        options.add("SuperCraft");
        options.add("Pika");
        
        GGEZ.instance.settingsManager.rSetting(new Setting("Flight Mode", this, "Vanilla", options));
        GGEZ.instance.settingsManager.rSetting(new Setting("github1 Speed", this, speed, 1, 20, false));
        GGEZ.instance.settingsManager.rSetting(new Setting("Damage", this, false));
        GGEZ.instance.settingsManager.rSetting(new Setting("Timer", this, false));  
	}
	
	public void onDisable() {

		mc.thePlayer.motionX *= 1.0;
		mc.thePlayer.motionX *= 1.0;
		
		if(singledamage == true) {
			singledamage = false;
		}
		if(singledamage1 == true) {
			singledamage1 = false;
		}
		
		mc.thePlayer.capabilities.isFlying = false;
		Invoker.setTimerSpeed(1.0f);
		super.onDisable();
	}
	
	public void onUpdate() {
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("Vanilla")) {
			mc.thePlayer.capabilities.isFlying = true;
			
			if(mc.gameSettings.keyBindJump.isPressed()) {
				mc.thePlayer.motionY += 0.2f;
			}
			if(mc.gameSettings.keyBindSneak.isPressed()) {
				mc.thePlayer.motionY -= 0.2f;
			}
			if(mc.gameSettings.keyBindForward.isPressed()) {
				mc.thePlayer.capabilities.setFlySpeed(flyHackSpeed);
			}
			
		}
			
			
			if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("Hypixel")) {
				if(this.mc.thePlayer.onGround) {
		  			this.mc.thePlayer.jump();
		  		} else {
		  			this.mc.thePlayer.motionY = 0;
		  			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY + 1.0E-12D, this.mc.thePlayer.posZ);
		  		}
			}
			
			if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("CubeCraft")) {
				mc.thePlayer.capabilities.isFlying = true;
				net.minecraft.util.Timer.timerSpeed = 0.29f;
			}
			
			if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("github1")) {
					speed = (float) GGEZ.instance.settingsManager.getSettingByName("github1 Speed").getValDouble();
					mc.thePlayer.capabilities.isFlying = false;
					mc.thePlayer.isInWeb = false;
					mc.thePlayer.motionY = 0;
					mc.thePlayer.motionX = 0;
					mc.thePlayer.motionZ = 0;
					mc.thePlayer.jumpMovementFactor = speed;
					
					if (mc.gameSettings.keyBindJump.getIsKeyPressed())
					{
						mc.thePlayer.motionY = speed;
					}
					
					if (mc.gameSettings.keyBindSneak.getIsKeyPressed())
					{
						mc.thePlayer.motionY = 0 - speed;
					}
			}
			
			if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("BattleAsya")) {
				
				mc.thePlayer.capabilities.isFlying = true;
				net.minecraft.util.Timer.timerSpeed = 0.29f;
				
			}
			
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly1") ) {
			if (player().isSneaking())
				player().motionY = -0.4;
			else if (mc.gameSettings.keyBindJump.isPressed())
				player().motionY = 0.4;
			else
				player().motionY = 0;
			player().motionX *= 1.1;
			player().motionZ *= 1.1;
		}
			
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly2")) {
			if (startY > player().posY)
				player().motionY = 0.5;
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly3")) {
			if(mc.thePlayer.onGround == true) mc.thePlayer.jump();
			else {
				int state = 0;
				mc.timer.timerSpeed = 0.70f;
				mc.thePlayer.motionY = 0;
				if(mc.gameSettings.keyBindJump.pressed == true) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.050, mc.thePlayer.posZ);
				}
				if(mc.gameSettings.keyBindSneak.pressed == true) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.050, mc.thePlayer.posZ);
				}
				
				if(state == 0) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.050, mc.thePlayer.posZ);
					state = 1;
				}
				if(state == 1) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.053, mc.thePlayer.posZ);
					state = 0;
				}
			}
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("MineLand")) {
			mc.thePlayer.motionY = 0;
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("McCentral")) {
			mc.thePlayer.cameraYaw = 0.090909086F * 2;
			mc.thePlayer.motionY = 0;
			
			mc.timer.timerSpeed = 1F;
			
			if(mc.thePlayer.isInvisible()) {
				mc.timer.timerSpeed = 1F;
			}
			
			if(timer.hasReached(1000L)) {
				
				
				timer.reset();
			}
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACENTRAMC")) {
			mc.timer.timerSpeed = 11f;
			speed = (float) 8.44;
			mc.thePlayer.capabilities.isFlying = false;
			mc.thePlayer.isInWeb = false;
			mc.thePlayer.motionY = 0;
			mc.thePlayer.motionX = 0;
			mc.thePlayer.motionZ = 0;
			mc.thePlayer.jumpMovementFactor = speed;
			
			if (mc.gameSettings.keyBindJump.getIsKeyPressed())
			{
				mc.thePlayer.motionY = speed;
			}
			
			if (mc.gameSettings.keyBindSneak.getIsKeyPressed())
			{
				mc.thePlayer.motionY = 0 - speed;
			}
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("SuperCraft")) {
			if(mc.thePlayer.onGround) {
				mc.thePlayer.jump();
			}else {
				mc.timer.timerSpeed = 2f;
				mc.thePlayer.motionY = 0;
				if(timer.hasReached(200L)) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.30f, mc.thePlayer.posZ);
					timer.reset();
				}
			}
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("Pika")) {
			if(mc.thePlayer.onGround) {
				mc.thePlayer.jump();
			}else {
				mc.timer.timerSpeed = 2f;
				mc.thePlayer.motionY = 0;
				if(timer.hasReached(200L)) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.30f, mc.thePlayer.posZ);
					timer.reset();
				}
			}
		}
		
			super.onDisable();
		}
	
	private void damage() {
		if(! (this.mc.theWorld.getBlockState(new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 4, this.mc.thePlayer.posZ)).getBlock() instanceof BlockAir)) {
			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 4, this.mc.thePlayer.posZ);
			GGEZ.instance.moduleManager.addChatMessage("Place a block before landing!");
		} else {
			GGEZ.instance.moduleManager.addChatMessage("You have to have 4 Solid blocks under you!");
		}
	}
	
	private void damage1() {
		if(singledamage == false) {
			if(! (this.mc.theWorld.getBlockState(new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 4, this.mc.thePlayer.posZ)).getBlock() instanceof BlockAir)) {
			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 4, this.mc.thePlayer.posZ);
			GGEZ.instance.moduleManager.addChatMessage("Place a block before landing!");
			} else {
			GGEZ.instance.moduleManager.addChatMessage("You have to have 4 Solid blocks under you!");
			singledamage1 = true;
			}
		}
	}
	
	public void onEnable() {
		
		if(GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("Damage")) {
			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 0.2, this.mc.thePlayer.posZ);
			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY + 0.2, this.mc.thePlayer.posZ);
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("nauticmcBypass")) {

			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY - 0.2, this.mc.thePlayer.posZ);
			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX, this.mc.thePlayer.posY + 0.2, this.mc.thePlayer.posZ);
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Flight Mode").getValString().equalsIgnoreCase("ACFly2")) {
			startY = player().posY;
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Damage").getValBoolean()) {
			damage();
		}
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("Timer").getValBoolean()) {
			net.minecraft.util.Timer.timerSpeed = 0.28f;
		}
	}
	}


