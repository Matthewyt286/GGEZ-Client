package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

import net.minecraft.client.Minecraft;

public class Freecam extends Module{
	protected Minecraft mc = Minecraft.getMinecraft();
	
	public Freecam() {
		super("Freecam", Keyboard.KEY_F4, Category.MOVEMENT);
	}
	
	public double _posX, _posY, _posZ;
	
	public void onPreMotionUpdates() {
		 mc.thePlayer.capabilities.isFlying = true;
	}
	 
	 public void onEnable() {
		 mc.thePlayer.noClip = true;
		 _posX = mc.thePlayer.posX;
		 _posY = mc.thePlayer.posY;
		 _posZ = mc.thePlayer.posZ;
	 }

	 public void onDisable() {
		 this.mc.thePlayer.noClip = false;
		 this.mc.thePlayer.capabilities.isFlying = false;
		 this.mc.thePlayer.setPosition(_posX, _posY, _posZ);
	 }

}