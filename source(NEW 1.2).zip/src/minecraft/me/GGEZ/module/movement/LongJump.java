package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.TimerUtils;

public class LongJump extends Module {

	public TimerUtils timer = new TimerUtils();

	public LongJump() {
		super("LongJump", Keyboard.KEY_C, Category.MOVEMENT);
	}

	@Override
	public void onDisable() {
		mc.timer.timerSpeed = 1f;
	}
	
	@Override
	public void onEnable() {
		this.mc.thePlayer.setPosition(this.mc.thePlayer.lastTickPosX - 0.3, this.mc.thePlayer.lastTickPosY - 0.3, this.mc.thePlayer.lastTickPosZ - 0.3);
		this.mc.thePlayer.setPosition(this.mc.thePlayer.posX + 0.3, this.mc.thePlayer.posY + 0.3, this.mc.thePlayer.posZ + 0.3);
	}
	
	@Override
	public void onUpdate() {
		if (this.isToggled()) {
			if (mc.gameSettings.keyBindJump.pressed) {
				mc.timer.timerSpeed = 0.5f;
				mc.thePlayer.setSprinting(toggled);
				mc.thePlayer.jump();
				mc.thePlayer.moveStrafing = 2f;
			}
		}
	}

}
