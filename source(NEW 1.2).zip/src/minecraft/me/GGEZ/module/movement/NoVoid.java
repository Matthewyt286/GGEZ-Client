package me.GGEZ.module.movement;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

public class NoVoid extends Module {

	public NoVoid() {
		super("NoVoid", 0, Category.MOVEMENT);
		// TODO Auto-generated constructor stub
	}

	@Override
    public void onUpdate() {
        if(this.isToggled()) {
            if (getMc().thePlayer.fallDistance > 2.5) {
                if (getMc().thePlayer.posY < 0) {
                } else {
                    for (int i = (int) Math.ceil(getMc().thePlayer.posY); i >= 0; i--) {
                        if (getMc().theWorld.getBlockState(new BlockPos(getMc().thePlayer.posX, i, getMc().thePlayer.posZ)).getBlock() != Blocks.air) {
                            return;
                        }
                    }
                    mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 4.42f, mc.thePlayer.posZ);
                }
            }
        }
    }
}