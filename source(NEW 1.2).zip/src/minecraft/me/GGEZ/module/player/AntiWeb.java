package me.GGEZ.module.player;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class AntiWeb extends Module{

	public AntiWeb() {
		super("AntiWeb", 0, Category.PLAYER);
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			mc.thePlayer.isInWeb = false;
		}
	}

}
