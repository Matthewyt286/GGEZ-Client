package me.GGEZ.module.player;

import io.netty.util.internal.ThreadLocalRandom;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.TimerUtils;
import net.minecraft.network.play.client.C01PacketChatMessage;

public class Spammer extends Module{

	public TimerUtils timer = new TimerUtils();
	
	public Spammer() {
		super("Spammer", 0, Category.PLAYER);
	}
	
	@Override
	public void onUpdate() {
		if(!this.isToggled()) {
			return;
		}
//		if(timer.hasReached(3000L)) {
//			int number = ThreadLocalRandom.current().nextInt() + ThreadLocalRandom.current().nextInt() + ThreadLocalRandom.current().nextInt() + ThreadLocalRandom.current().nextInt();
//			C01PacketChatMessage packet = new C01PacketChatMessage("GGEZ: subscribe to Matthew286 (@Matthew286_) on YT " + number);
//			mc.thePlayer.sendQueue.addToSendQueue(packet);
//			timer.reset();
//		}
		int var0 = ThreadLocalRandom.current().nextInt(0, 3);
		if(timer.hasReached(2000L)) {
			int var1 = ThreadLocalRandom.current().nextInt(0, 9) + ThreadLocalRandom.current().nextInt(0, 9) + ThreadLocalRandom.current().nextInt(0, 9) + ThreadLocalRandom.current().nextInt(0, 9);
			if(var0 == 0) {
				C01PacketChatMessage packet = new C01PacketChatMessage("GGEZ: subscribe to Matthew286 (@Matthew286_) on YT " + var1);
				mc.thePlayer.sendQueue.addToSendQueue(packet);
				timer.reset();
			}
			if(var0 == 1) {
				C01PacketChatMessage packet = new C01PacketChatMessage("GGEZ: what!! you didnt sub to Matthew286 on YT!??! " + var1);
				mc.thePlayer.sendQueue.addToSendQueue(packet);
				timer.reset();
			}
			if(var0 == 2) {
				C01PacketChatMessage packet = new C01PacketChatMessage("GGEZ: I cant belive it... you didnt sub to Matthew286?? " + var1);
				mc.thePlayer.sendQueue.addToSendQueue(packet);
				timer.reset();
			}
		}
	}

}
