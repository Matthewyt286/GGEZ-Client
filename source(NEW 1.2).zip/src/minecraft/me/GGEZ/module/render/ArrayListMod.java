package me.GGEZ.module.render;

import de.Hero.settings.Setting;
import me.GGEZ.DumbVar;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class ArrayListMod extends Module{

	int arraycolor1 = 1;
	int state = 0;
	
	public ArrayListMod() {
		super("ArrayList", 0, Category.RENDER);
	}
	
	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("Enable Array", this, true));
		GGEZ.instance.settingsManager.rSetting(new Setting("Array Rainbow", this, true));
		GGEZ.instance.settingsManager.rSetting(new Setting("Array Rect", this, true));
	}
	
	public void onEnable() {
		GGEZ.instance.hud.drawArray();
		if(GGEZ.instance.settingsManager.getSettingByName("Array Rainbow").getValBoolean()) {
			DumbVar.ArrayColor = 1;
		}else
			DumbVar.ArrayColor = 2;
		
		if(GGEZ.instance.settingsManager.getSettingByName("Array Rect").getValBoolean()) {
			DumbVar.ArrayRect = 1;
		}else
			DumbVar.ArrayRect = 0;
		
		if(GGEZ.instance.settingsManager.getSettingByName("Enable Array").getValBoolean()) {
			DumbVar.Array = 1;
		}else {
			DumbVar.Array = 0;
		}
		toggle();
	}
	
	public void onDisable() {
		
	}

}
