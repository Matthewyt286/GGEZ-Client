package me.GGEZ.module.render;

import me.GGEZ.module.Module;
import me.GGEZ.DumbVar;
import me.GGEZ.module.Category;

public class BlockAnimations extends Module{

	public BlockAnimations() {
		super("BlockAnimations", 0, Category.RENDER);
	}
	
	@Override
	public void onEnable() {
		DumbVar.fakeNoSlow = 1;
	}
	
	@Override
	public void onDisable() {
		DumbVar.fakeNoSlow = 0;
	}
	
}
