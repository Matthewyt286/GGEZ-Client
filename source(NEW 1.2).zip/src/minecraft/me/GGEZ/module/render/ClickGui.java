package me.GGEZ.module.render;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class ClickGui extends Module{

        public ClickGui() {
        super("ClickGui", Keyboard.KEY_RSHIFT, Category.RENDER);
    }

    @Override
    public void setup() {
        ArrayList<String> options = new ArrayList<>();
        options.add("New");
        options.add("JellyLike");
        GGEZ.instance.settingsManager.rSetting(new Setting("Design", this, "New", options));
        GGEZ.instance.settingsManager.rSetting(new Setting("Sound", this, false));
        GGEZ.instance.settingsManager.rSetting(new Setting("GuiRed", this, 255, 0, 255, true));
        GGEZ.instance.settingsManager.rSetting(new Setting("GuiGreen", this, 26, 0, 255, true));
        GGEZ.instance.settingsManager.rSetting(new Setting("GuiBlue", this, 42, 0, 255, true));
    }

    @Override
    public void onEnable() {
        super.onEnable();

        mc.displayGuiScreen(GGEZ.instance.clickGUI);
        toggle();
    }
}