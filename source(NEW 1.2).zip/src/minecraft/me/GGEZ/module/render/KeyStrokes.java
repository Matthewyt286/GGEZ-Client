package me.GGEZ.module.render;

import de.Hero.settings.Setting;
import me.GGEZ.DumbVar;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class KeyStrokes extends Module{

	public KeyStrokes() {
		super("KeyStrokes", 0, Category.RENDER);
	}
	
	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("Enable KeyStrokes", this, true));
	}
	
	@Override
	public void onEnable() {
		if(GGEZ.instance.settingsManager.getSettingByName("Enable KeyStrokes").getValBoolean()) {
			DumbVar.keystrokes = 1;
		}else {
			DumbVar.keystrokes = 0;
		}
		toggle();
	}

}
