package me.GGEZ.module.render;

import me.GGEZ.DumbVar;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class NoHurtCam extends Module{

	public NoHurtCam() {
		super("NoHurtCam", 0, Category.RENDER);
	}
	
	@Override
	public void onEnable() {
		DumbVar.NoHurtCam = 1;
	}
	
	@Override
	public void onDisable() {
		DumbVar.NoHurtCam = 0;
	}

}
