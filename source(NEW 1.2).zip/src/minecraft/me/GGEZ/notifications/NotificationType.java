package me.GGEZ.notifications;

public enum NotificationType {
    INFO, WARNING, ERROR;
}
