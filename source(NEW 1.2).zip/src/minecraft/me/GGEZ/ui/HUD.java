package me.GGEZ.ui;

import java.awt.Color;
import java.util.Collections;
import java.util.Comparator;

import org.lwjgl.input.Keyboard;

import de.Hero.clickgui.util.FontUtil;
import me.GGEZ.DumbVar;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Module;
import me.GGEZ.utils.ColorUtils;
import me.GGEZ.utils.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.item.EntityItemFrame;

public class HUD {

	public Minecraft mc = Minecraft.getMinecraft();

	public static class ModuleComparator implements Comparator<Module> {

		@Override
		public int compare(Module o1, Module o2) {
			if (Minecraft.getMinecraft().fontRendererObj
					.getStringWidth(o1.name) > Minecraft.getMinecraft().fontRendererObj.getStringWidth(o2.name)) {
				return -1;
			}
			if (Minecraft.getMinecraft().fontRendererObj
					.getStringWidth(o1.name) < Minecraft.getMinecraft().fontRendererObj.getStringWidth(o2.name)) {
				return 1;
			}

			return 0;
		}

	}

	public void drawKeyStrokes() {
		ScaledResolution sr = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);

		int wAlpha = (Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode()) ? 125 : 50);
		int aAlpha = (Keyboard.isKeyDown(mc.gameSettings.keyBindLeft.getKeyCode()) ? 125 : 50);
		int sAlpha = (Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode()) ? 125 : 50);
		int dAlpha = (Keyboard.isKeyDown(mc.gameSettings.keyBindRight.getKeyCode()) ? 125 : 50);

		Gui.drawRect(sr.getScaledWidth() - 29 - 29, sr.getScaledHeight() - 4 - 25 - 29, sr.getScaledWidth() - 4 - 29,
				sr.getScaledHeight() - 4 - 29, new Color(0, 0, 0, wAlpha).getRGB());
		Gui.drawRect(sr.getScaledWidth() - 29 - 29 - 29, sr.getScaledHeight() - 4 - 25,
				sr.getScaledWidth() - 4 - 29 - 29, sr.getScaledHeight() - 4, new Color(0, 0, 0, aAlpha).getRGB());
		Gui.drawRect(sr.getScaledWidth() - 29 - 29, sr.getScaledHeight() - 4 - 25, sr.getScaledWidth() - 4 - 29,
				sr.getScaledHeight() - 4, new Color(0, 0, 0, sAlpha).getRGB());
		Gui.drawRect(sr.getScaledWidth() - 29, sr.getScaledHeight() - 4 - 25, sr.getScaledWidth() - 4,
				sr.getScaledHeight() - 4, new Color(0, 0, 0, dAlpha).getRGB());

		Wrapper.fr.drawString("W", sr.getScaledWidth() - 48, sr.getScaledHeight() - 49, 0xffffffff);
		Wrapper.fr.drawString("A", sr.getScaledWidth() - 77, sr.getScaledHeight() - 20, 0xffffffff);
		Wrapper.fr.drawString("S", sr.getScaledWidth() - 48.5, sr.getScaledHeight() - 20, 0xffffffff);
		Wrapper.fr.drawString("D", sr.getScaledWidth() - 19, sr.getScaledHeight() - 20, 0xffffffff);
	}

	public void drawArray() {
		if (DumbVar.skin == 0) {
			if (DumbVar.Array == 1) {
				if (DumbVar.ArrayColor == 1) {
					if (DumbVar.ArrayRect == 1)
						drawArrayRainbow();
				}
			}
		}
	}

	public void drawArrayRainbow() {
		ScaledResolution sr = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
		FontRenderer fr = mc.fontRendererObj;

		if (DumbVar.Array == 1) {
			int count = 0;

			for (Module m : GGEZ.instance.moduleManager.getModules()) {
				if (!m.isToggled())
					continue;

				double offset = count * (fr.FONT_HEIGHT + 6);

				
				
				Gui.drawRect(sr.getScaledWidth() - Wrapper.fr.getStringWidth(m.getName()) - 8, offset,
						sr.getScaledWidth(), 6 + Wrapper.fr.FONT_HEIGHT + offset, 0x90000000);
				
				Gui.drawRect(sr.getScaledWidth() - 3 - fr.getStringWidth(m.getName()) - 5, offset,
						sr.getScaledWidth() - fr.getStringWidth(m.getName()) - 4,
						6 + Wrapper.fr.FONT_HEIGHT + offset,
						ColorUtils.rainbowEffect(count * 200000000L, 1.0F).getRGB());
				
				FontUtil.drawStringWithShadow(m.getName(),
						sr.getScaledWidth() - Wrapper.fr.getStringWidth(m.getName()) - 5 + 3, 4 + offset,
						ColorUtils.rainbowEffect(count * 200000000L, 1.0F).getRGB());

				count++;
			}
		}
	}

	public void drawHud() {
		if (DumbVar.skin == 0) {
			if (DumbVar.HudColor == 1) {
				if (DumbVar.HudRect == 1)
					drawHudRainbow();
			}
		}
	}

	public void drawHudRainbow() {
		ScaledResolution sr = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
		FontRenderer fr = mc.fontRendererObj;

		Collections.sort(GGEZ.moduleManager.getModules(), new ModuleComparator());

		if (DumbVar.Hud == 1) {
			GlStateManager.pushMatrix();
			GlStateManager.scale(2.2, 2.2, 2.2);
			FontUtil.drawStringWithShadow(GGEZ.name, 3, 5,
					ColorUtils.rainbowEffect(2 * 2000000000L, 1.0F).getRGB());
			GlStateManager.popMatrix();
			FontUtil.drawStringWithShadow("FPS:" + mc.func_175610_ah(),
				61, 20, -1);
			FontUtil.drawStringWithShadow("public relase v1.1",
					61, 10, ColorUtils.rainbowEffect(2 * 2L, 1.0F).getRGB());
		}

	}
}
