package me.GGEZ.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public final class RotationUtil {

	public static float[] getRotations(EntityLivingBase target) {
		float yaw, pitch;
		Vec3 targetPos = new Vec3(target.posX, target.posY, target.posZ);
		Vec3 playerPos = new Vec3(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
		
		double var1 = targetPos.xCoord - playerPos.xCoord;
        double var3 = targetPos.yCoord - playerPos.yCoord;
        double var5 = targetPos.zCoord - playerPos.zCoord;
        double var7 = (double)MathHelper.sqrt_double(var1 * var1 + var5 * var5);
        float var9 = (float)(Math.atan2(var5, var1) * 180.0D / Math.PI) - 90.0F;
        float var10 = (float)(-(Math.atan2(var3, var7) * 180.0D / Math.PI));
        
        yaw =var9;
        pitch = var10;
        
//        this.entity.rotationPitch = this.updateRotation(this.entity.rotationPitch, var10, this.deltaLookPitch);
//        this.entity.rotationYawHead = this.updateRotation(this.entity.rotationYawHead, var9, this.deltaLookYaw);
        return new float[] {yaw, pitch};
	}
	
}
