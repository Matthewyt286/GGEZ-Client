package me.GGEZ.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.multiplayer.WorldClient;

public class Wrapper {
	
	public static Minecraft mc = Minecraft.getMinecraft();
	public static FontRenderer fr = mc.fontRendererObj;
	
	public static final WorldClient getWorld() {
		return Minecraft.getMinecraft().theWorld;
	}

}
