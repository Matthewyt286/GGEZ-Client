package me.GGEZ;

public class DumbVar {
	
	public static int Tab = 0;
	public static int fakeNoSlow = 0;
	
	public static int Array = 1;
	public static int ArrayColor = 1;
	public static int ArrayRect = 1;
	
	public static int Hud = 1;
	public static int HudColor = 1;
	public static int HudRect = 1;

	public static int NoHurtCam = 0;
	
	public static int skin = 0;
	
	public static int keystrokes = 0;
	
	public static int Sound = 1;
	
	public static int chestStealer = 0;
}
