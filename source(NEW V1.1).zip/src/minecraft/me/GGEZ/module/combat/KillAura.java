package me.GGEZ.module.combat;

import java.util.Iterator;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.DumbVar;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.TimerUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C03PacketPlayer;

public class KillAura extends Module {

	private double range;
	private int delay;
	
	private TimerUtils timer = new TimerUtils();
	
	public KillAura() {
		super("KillAura2", 0, Category.COMBAT);
	}

	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("KA Range", this, 6.2173613F, 0, 6.2173613F, false));
		GGEZ.instance.settingsManager.rSetting(new Setting("KA Delay", this, 0, 0, 10, false));
	}
	
	@Override
	public void onUpdate() {
		 range = GGEZ.instance.settingsManager.getSettingByName("KA Range").getValDouble();
		 delay = (int) GGEZ.instance.settingsManager.getSettingByName("KA Delay").getValDouble();
		if (!this.isToggled())
			return;

		for (Iterator<Entity> entities = mc.theWorld.loadedEntityList.iterator(); entities.hasNext();) {
			Object theObject = entities.next();
			if (theObject instanceof EntityLivingBase) {
				EntityLivingBase entity = (EntityLivingBase) theObject;

				if (entity instanceof EntityPlayerSP)
					continue;

				if (mc.thePlayer.getDistanceToEntity(entity) <= range) {
					if(timer.hasReached(delay * 1000)) {
						if (entity.isEntityAlive()) {

							float yaw = getRotations(entity)[0];
							float pitch = getRotations(entity)[1];
							
							mc.thePlayer.rotationYawHead = yaw;
							mc.thePlayer.rotationPitchHead = pitch;
							
							mc.thePlayer.rotationYawHead = yaw;
							mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(yaw, pitch, mc.thePlayer.onGround));
							
							mc.playerController.attackEntity(mc.thePlayer, entity);
							mc.thePlayer.swingItem();
							
							timer.reset();
							continue;
							
						}
					}
				}
			}
		}

		super.onUpdate();
	}
	
	@Override
	public void onEnable() {
		DumbVar.fakeNoSlow = 1;
	}
	
	@Override
	public void onDisable() {
		DumbVar.fakeNoSlow = 0;
	}
	
	public float[] getRotations(Entity e) {
		double deltaX = e.posX + (e.posX - e.lastTickPosX) - mc.thePlayer.posX;
		double deltaY = e.posY - 3.5 + e.getEyeHeight() - mc.thePlayer.posY + mc.thePlayer.getEyeHeight();
		double deltaZ = e.posZ + (e.posZ - e.lastTickPosZ) - mc.thePlayer.posZ;
		double distance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaZ, 2));
		float yaw = (float) Math.toDegrees(-Math.atan(deltaX / deltaZ));
		float pitch = (float) -Math.toDegrees(Math.atan(deltaY / distance));
		
		if(deltaX < 0  && deltaZ < 0) {
			yaw = (float) (90 + Math.toDegrees(Math.atan(deltaZ / deltaX)));
		}else if(deltaX > 0 && deltaZ < 0) {
			yaw = (float) (-90 + Math.toDegrees(Math.atan(deltaZ / deltaX)));
		}
		
		return new float[]  { yaw , pitch};
		
		}
	
}
