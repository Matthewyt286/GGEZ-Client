package me.GGEZ.module.combat;

import java.util.ArrayList;
import java.util.List;

import me.GGEZ.DumbVar;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.MathHelper;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;

public class KillAuraLegit extends Module {

	public static float yaw;
	public static float pitch;
	
	public KillAuraLegit() {
		super("KillAuraLegit", Keyboard.KEY_H, Category.COMBAT);
	}
	
	public void onUpdate() {
		if (this.isToggled()) {
			this.killaura();
		}
	}

	public void onDisable() {
		DumbVar.fakeNoSlow = 0;
		mc.thePlayer.rotationYaw = yaw;
		mc.thePlayer.rotationPitch = pitch;
		
		
	}
	
	public void onEnable() {
		DumbVar.fakeNoSlow = 1;
		yaw = mc.thePlayer.rotationYaw;
		pitch = mc.thePlayer.rotationPitch;
		
	}
	
	public void setup() {
		
		
		
		ArrayList<String> options = new ArrayList<>();
		options.add("Delay");
		GGEZ.instance.settingsManager.rSetting(new Setting("Delay", this, Delay1, 1, 20, false));	
	}
	
	private int Delay1 = (int) GGEZ.instance.settingsManager.getSettingByName("Delay").getValDouble();
	int Delay;

	private void killaura() {
		
		
		List list = Wrapper.mc.theWorld.playerEntities;
		Delay++;

		for (int k = 0; k < list.size(); k++) {
			if (((EntityPlayer) list.get(k)).getName() == Wrapper.mc.thePlayer.getName()) {
				continue;
			}

			EntityPlayer entityplayer = (EntityPlayer) list.get(1);

			if (Wrapper.mc.thePlayer.getDistanceToEntity(entityplayer) > Wrapper.mc.thePlayer.getDistanceToEntity((Entity) list.get(k))) {
				entityplayer = (EntityPlayer) list.get(k);
			}

			float f = Wrapper.mc.thePlayer.getDistanceToEntity(entityplayer);

			if (f < 4F && Wrapper.mc.thePlayer.canEntityBeSeen(entityplayer) && Delay > Delay1 && (mc.thePlayer.getDistanceToEntity(entityplayer) <= 3.0f)) {
				this.faceEntity(entityplayer);
				Wrapper.mc.playerController.attackEntity(Wrapper.mc.thePlayer, entityplayer);
				Wrapper.mc.thePlayer.swingItem();
				Delay = 0;
				continue;
			}
		}
	}

	public static synchronized void faceEntity(EntityLivingBase entity) {
		final float[] rotations = getRotationsNeeded(entity);

		if (rotations != null) {
			Minecraft.getMinecraft().thePlayer.rotationYaw = rotations[0];
			Minecraft.getMinecraft().thePlayer.rotationPitch = rotations[1] + 1.0F;// 14
		}
		
		Minecraft.getMinecraft().thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(yaw, pitch, Minecraft.getMinecraft().thePlayer.onGround));
	}

	public static float[] getRotationsNeeded(Entity entity) {
		if (entity == null) {
			return null;
		}

		final double diffX = entity.posX - Minecraft.getMinecraft().thePlayer.posX;
		final double diffZ = entity.posZ - Minecraft.getMinecraft().thePlayer.posZ;
		double diffY;

		if (entity instanceof EntityLivingBase) {
			final EntityLivingBase entityLivingBase = (EntityLivingBase) entity;
			diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
		} else {
			diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
		}

		final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
		final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
		final float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);
		return new float[] { Minecraft.getMinecraft().thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Minecraft.getMinecraft().thePlayer.rotationYaw), Minecraft.getMinecraft().thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.getMinecraft().thePlayer.rotationPitch) };
	}
	
	public float[] getRotations(Entity e) {
		double deltaX = e.posX + (e.posX - e.lastTickPosX) - mc.thePlayer.posX;
		double deltaY = e.posY - 3.5 + e.getEyeHeight() - mc.thePlayer.posY + mc.thePlayer.getEyeHeight();
		double deltaZ = e.posZ + (e.posZ - e.lastTickPosZ) - mc.thePlayer.posZ;
		double distance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaZ, 2));
		float yaw = (float) Math.toDegrees(-Math.atan(deltaX / deltaZ));
		float pitch = (float) -Math.toDegrees(Math.atan(deltaY / distance));
		
		if(deltaX < 0  && deltaZ < 0) {
			yaw = (float) (90 + Math.toDegrees(Math.atan(deltaZ / deltaX)));
		}else if(deltaX > 0 && deltaZ < 0) {
			yaw = (float) (-90 + Math.toDegrees(Math.atan(deltaZ / deltaX)));
		}
		
		return new float[]  { yaw , pitch};
		
		}

}