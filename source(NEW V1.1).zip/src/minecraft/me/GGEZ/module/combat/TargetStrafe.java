package me.GGEZ.module.combat;

import java.util.ArrayList;
import java.util.Iterator;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class TargetStrafe extends Module {

	public TargetStrafe() {
		super("TargetStrafe", Keyboard.KEY_L, Category.COMBAT);
	}

	private double TRange = GGEZ.instance.settingsManager.getSettingByName("Target Range").getValDouble();
	private double motionXZ = GGEZ.instance.settingsManager.getSettingByName("motionXZ").getValDouble();

	public void setup() {
		ArrayList<String> options = new ArrayList<>();
		options.add("Range");
		GGEZ.instance.settingsManager.rSetting(new Setting("Target Range", this, TRange, 1, 10, false));
		GGEZ.instance.settingsManager.rSetting(new Setting("motionXZ", this, motionXZ, 0.50, 2, false));
	}

	public void onUpdate() {
		if (this.isToggled()) {
			for (Iterator<Entity> entities = mc.theWorld.loadedEntityList.iterator(); entities.hasNext();) {
				Object theObject = entities.next();
				if (theObject instanceof EntityLivingBase) {
					EntityLivingBase entity = (EntityLivingBase) theObject;

					if (entity instanceof EntityPlayerSP)
						continue;

					if (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 4) + Math.pow(mc.thePlayer.posZ - entity.posZ, 4)) != 0) {
						double posX = (mc.thePlayer.posX - entity.posX) / (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 2) + Math.pow(mc.thePlayer.posZ - entity.posZ, 2)));
						double posZ = (mc.thePlayer.posZ - entity.posZ) / (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 2) + Math.pow(mc.thePlayer.posZ - entity.posZ, 2)));
						if (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 2) + Math.pow(mc.thePlayer.posZ - entity.posZ, 2)) < (GGEZ.instance.settingsManager.getSettingByName("Target Range").getValDouble() / 1.5) && !entity.isDead) {
							float strafe = mc.thePlayer.moveForward / 4f;
							double codeX = -strafe * posZ - 0.03 * strafe * posX;
							double codeZ = strafe * posX - 0.03 * strafe * posZ;
							double moveX = mc.gameSettings.keyBindLeft.pressed ? codeX : -codeX;
							double moveZ = mc.gameSettings.keyBindLeft.pressed ? codeZ : -codeZ;
							mc.thePlayer.motionX = moveX;
							mc.thePlayer.motionZ = moveZ;

						}
					}

//					if (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 2) + Math.pow(mc.thePlayer.posZ - entity.posZ, 2)) != 0) {
//						double c1 = (mc.thePlayer.posX - entity.posX) / (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 2)	+ Math.pow(mc.thePlayer.posZ - entity.posZ, 2)));
//						double s1 = (mc.thePlayer.posZ - entity.posZ) / (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 2) + Math.pow(mc.thePlayer.posZ - entity.posZ, 2)));
//						if (Math.sqrt(Math.pow(mc.thePlayer.posX - entity.posX, 2) + Math.pow(mc.thePlayer.posZ - entity.posZ, 2)) <= TRange && !mc.thePlayer.isDead) {
//							if (mc.gameSettings.keyBindLeft.pressed) {
//								mc.thePlayer.motionX = -motionXZ * s1 - 0.18 * motionXZ * c1;
//								mc.thePlayer.motionZ = motionXZ * c1 - 0.18 * motionXZ * s1;
//							} else {
//								mc.thePlayer.motionX = motionXZ * s1 - 0.18 * motionXZ * c1;
//								mc.thePlayer.motionZ = -motionXZ * c1 - 0.18 * motionXZ * s1;
//							}
//						}
//
//					}
				}
			}
		}
	}
}
