package me.GGEZ.module.misc;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class Disabler extends Module{

	public Disabler() {
		super("SmartDisabler", 0, Category.MISC);
	}
	
	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("onDeath", this, false));
	}
	
	private static void disable() {
		for(Module m : GGEZ.instance.moduleManager.getModules()) {
			if(m.getName() == "KillAura") {
				m.toggled = false;
			}
			if(m.getName() == "KillAura2") {
				m.toggled = false;
			}
			if(m.getName() == "KillAuraLegit") {
				m.toggled = false;
			}
			if(m.getName() == "TargetStrafe") {
				m.toggled = false;
			}
			if(m.getName() == "Aimbot") {
				m.toggled = false;
			}
			if(m.getName() == "InventoryManager") {
				m.toggled = false;
			}
			if(m.getName() == "InvManager") {
				m.toggled = false;
			}
			if(m.getName() == "Flight") {
				m.toggled = false;
			}
			if(m.getName() == "BHop") {
				m.toggled = false;
			}
			if(m.getName() == "JetPack") {
				m.toggled = false;
			}
			if(m.getName() == "Scaffold") {
				m.toggled = false;
			}
			if(m.getName() == "Speed") {
				m.toggled = false;
			}
			if(m.getName() == "Eagle") {
				m.toggled = false;
			}
			if(m.getName() == "AntiWeb") {
				m.toggled = false;
			}
			if(m.getName() == "LadderHighJump") {
				m.toggled = false;
			}
			if(m.getName() == "BedNuker") {
				m.toggled = false;
			}
			if(m.getName() == "Timer") {
				m.toggled = false;
			}
			if(m.getName() == "FakeLag") {
				m.toggled = false;
			}
			if(m.getName() == "ServerCrasher") {
				m.toggled = false;
			}
			if(m.getName() == "SmartDisabler") {
				m.toggled = false;
			}
		}
	}
	
	@Override
	public void onUpdate() {
		if(GGEZ.instance.settingsManager.getSettingByName("onDeath").getValBoolean()) {
			if(mc.thePlayer.isDead) {
				disable();
			}
		}else{}
	}

	public void onEnable() {
		if(GGEZ.instance.settingsManager.getSettingByName("onDeath").getValBoolean() != true) {
			disable();
		}
	}
	
}
