package me.GGEZ.module.misc;

import me.GGEZ.DumbVar;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class Sound extends Module{
	
	public Sound() {
		super("Sound", 0, Category.MISC);
	}
	
	@Override
	public void onUpdate() {
		if(DumbVar.Sound == 1) {
			toggled = true;
		}
		if(DumbVar.Sound == 0) {
			toggled = false;
		}
	}
	
	@Override
	public void onEnable() {
		DumbVar.Sound = 1;
	}
	
	@Override
	public void onDisable() {
		DumbVar.Sound = 0;
	}

}
