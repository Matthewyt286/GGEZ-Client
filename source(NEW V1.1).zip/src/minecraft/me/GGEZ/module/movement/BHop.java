package me.GGEZ.module.movement;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class BHop extends Module {

	protected boolean boosted = false;
	
	public BHop() {
		super("BHop", Keyboard.KEY_M, Category.MOVEMENT);
	}

	public void setup() {
		ArrayList<String> options = new ArrayList<>();
        options.add("idk");
        options.add("legit");
        
        GGEZ.instance.settingsManager.rSetting(new Setting("BHop Mode", this, "idk", options));
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			if (GGEZ.instance.settingsManager.getSettingByName("BHop Mode").getValString().equalsIgnoreCase("idk") && mc.gameSettings.keyBindJump.pressed != true) {
				int state = 0;
				if(state == 0) {
					mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.500, mc.thePlayer.posZ);
					mc.thePlayer.motionX *= 1.1;
					mc.thePlayer.motionZ *= 1.1;
					state = 1;
				}	
				if(state == 1) {
					mc.thePlayer.setPosition(mc.thePlayer.lastTickPosX, mc.thePlayer.posY - 0.150, mc.thePlayer.posZ);
					mc.thePlayer.motionX *= 1.0;
					mc.thePlayer.motionZ *= 1.0;
					state = 0;
				}

			}
			if(GGEZ.instance.settingsManager.getSettingByName("BHop Mode").getValString().equalsIgnoreCase("legit")) {
				if(this.mc.gameSettings.keyBindForward.pressed) {
					this.mc.gameSettings.keyBindSprint.pressed = true;
					if(this.mc.thePlayer.onGround) {
						this.mc.gameSettings.keyBindJump.pressed = false;
						this.mc.thePlayer.jump();
						this.boosted = false;
					} else {
						if(this.boosted) {
							this.mc.timer.timerSpeed = 1.28F;
							double motionV = 0.15;
							double x = this.mc.thePlayer.posX + this.mc.thePlayer.motionX + 15;
							double z = this.mc.thePlayer.posZ + this.mc.thePlayer.motionZ + 15;
							this.mc.thePlayer.motionX = x;
							this.mc.thePlayer.motionZ = z;
							this.boosted = false;
						}
					}
				}
			}
		}
	}

}
