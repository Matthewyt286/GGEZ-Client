package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class Glide2 extends Module{

	public Glide2() {
		super("Glide2", Keyboard.KEY_NONE, Category.MOVEMENT);
	}
	
	public void onUpdate() {
		if(this.isToggled()) {
			mc.thePlayer.motionY *= 0.5f;
		}
	}

}
