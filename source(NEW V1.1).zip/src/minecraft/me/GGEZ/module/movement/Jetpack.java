package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class Jetpack extends Module{

	public Jetpack() {
		super("JetPack", Keyboard.KEY_B, Category.MOVEMENT);
		
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			if(mc.gameSettings.keyBindJump.pressed) {
				mc.thePlayer.jump();
			}
		}
	}

}
