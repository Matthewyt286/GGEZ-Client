package me.GGEZ.module.player;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class FastPlace extends Module{

	public FastPlace() {
		super("FastPlace", Keyboard.KEY_K, Category.PLAYER);
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			mc.rightClickDelayTimer = 0;
		}
	}

}
