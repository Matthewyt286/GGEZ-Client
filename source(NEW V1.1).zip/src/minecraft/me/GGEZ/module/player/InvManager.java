package me.GGEZ.module.player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import io.netty.util.internal.ThreadLocalRandom;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.TimerUtils;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public class InvManager extends Module{
	
	private TimerUtils timer = new TimerUtils();
	
	private int[] bestArmorDamageReducement;
	private int[] bestArmorSlots;
	
	private float bestSwordDamage;
	private int bestSwordSlot;
	
	private static double dropdelay = 0;
	
	private List<Integer> trash = new ArrayList<>();
	
	public InvManager() {
		super("InvManager", Keyboard.KEY_V, Category.PLAYER);
	}
	
	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("PreferSwords", this, true));
		GGEZ.instance.settingsManager.rSetting(new Setting("Drop Delay", this, dropdelay, 0, 1000, false));
		
	}
	
	@Override
	public void onUpdate() {
		if(!this.isToggled())
			return;
		
		searchForItems();
		
		for(int i = 0; i < 4; i++) {
			if(bestArmorSlots[i] != -1) {
				int bestSlot = bestArmorSlots[i];
				
				ItemStack oldArmor = mc.thePlayer.inventory.armorItemInSlot(i);
				
				if(oldArmor != null && oldArmor.getItem() != null) {
					mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, 8 - i, 0, 1, mc.thePlayer);
					
					
				}
				
				mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, bestSlot < 9 ? bestSlot + 36 : bestSlot, 0, 1, mc.thePlayer);
			}
		}
		
		if(bestSwordSlot != -1 && bestSwordDamage != -1) {
			mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, bestSwordSlot < 9 ? bestSwordSlot + 36 : bestSwordSlot, 0, 2, mc.thePlayer);
		}
		
		searchForTrash();
		
		for(Integer integer : trash) {
			mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, integer < 9 ? integer + 36 : integer, 0, 4, mc.thePlayer);
		}
	}
	
	private void searchForItems() {
		bestArmorDamageReducement = new int[4];
		bestArmorSlots = new int[4];
		bestSwordDamage = -1;
		bestSwordSlot = -1;
		
		Arrays.fill(bestArmorDamageReducement, -1);
		Arrays.fill(bestArmorSlots, -1);
		
		for(int i = 0; i < bestArmorSlots.length; i++) {
			ItemStack itemStack = mc.thePlayer.inventory.armorItemInSlot(i);
			
			if(itemStack != null && itemStack.getItem() != null) {
				if(itemStack.getItem() instanceof ItemArmor) {
					ItemArmor armor = (ItemArmor) itemStack.getItem();
					
					bestArmorDamageReducement[i] = armor.damageReduceAmount;
				}
			}
		}
		for(int i = 0; i < 9 * 4; i++) {
			ItemStack itemStack = mc.thePlayer.inventory.getStackInSlot(i);
			
			if(itemStack == null || itemStack.getItem() == null) continue;
			
			if(itemStack.getItem() instanceof ItemArmor) {
				ItemArmor armor = (ItemArmor) itemStack.getItem();
				
				int armorType = 3 - armor.armorType;
				
				if(bestArmorDamageReducement[armorType] < armor.damageReduceAmount) {
					bestArmorDamageReducement[armorType] = armor.damageReduceAmount;
					bestArmorSlots[armorType] = i;
				}
			}
			
			if(itemStack.getItem() instanceof ItemSword) {
				ItemSword sword = (ItemSword) itemStack.getItem();
				
				if(bestSwordDamage < sword.func_150931_i()) {
					bestSwordDamage = sword.func_150931_i();
					bestSwordSlot = i;
				}
			}
			
 			if(itemStack.getItem() instanceof ItemTool) {
				ItemTool sword = (ItemTool) itemStack.getItem();
				
				float damage = sword.getToolMaterial().getDamageVsEntity();
				
				if(GGEZ.instance.settingsManager.getSettingByName("PreferSwords").getValBoolean())
					damage -= 1.0f;
				
				if(bestSwordDamage < damage) {
					bestSwordDamage = damage;
					bestSwordSlot = i;
				}
			}
		}
	}
	
	private void searchForTrash() {
		trash.clear();
		bestArmorDamageReducement = new int[4];
		bestArmorSlots = new int[4];
		bestSwordDamage = -1;
		bestSwordSlot = -1;
		
		Arrays.fill(bestArmorDamageReducement, -1);
		Arrays.fill(bestArmorSlots, -1);
		
		List<Integer>[] allItems = new List[4];
		
		List<Integer> allSwords = new ArrayList<>();
		
		for(int i = 0; i < bestArmorSlots.length; i++) {
			ItemStack itemStack = mc.thePlayer.inventory.armorItemInSlot(i);
			
			allItems[i] = new ArrayList<>();
			
			if(itemStack != null && itemStack.getItem() != null) {
				if(itemStack.getItem() instanceof ItemArmor) {
					ItemArmor armor = (ItemArmor) itemStack.getItem();
					
					bestArmorDamageReducement[i] = armor.damageReduceAmount;
					bestArmorSlots[i] = 8 + i;
				}
			}
		}
		for(int i = 0; i < 9 * 4; i++) {
			ItemStack itemStack = mc.thePlayer.inventory.getStackInSlot(i);
			if(itemStack == null || itemStack.getItem() == null) continue;
			
			if(itemStack.getItem() instanceof ItemArmor) {
				ItemArmor armor = (ItemArmor) itemStack.getItem();
				
				int armorType = 3 - armor.armorType;
				
				allItems[armorType].add(i);
				
				if(bestArmorDamageReducement[armorType] < armor.damageReduceAmount) {
					bestArmorDamageReducement[armorType] = armor.damageReduceAmount;
					bestArmorSlots[armorType] = i;
				}
			}
			
			if(itemStack.getItem() instanceof ItemSword) {
				ItemSword sword = (ItemSword) itemStack.getItem();

				allSwords.add(i);
				
				if(bestSwordDamage < sword.func_150931_i()) {
					bestSwordDamage = sword.func_150931_i();
					bestSwordSlot = i;
				}
			}
			
			if(itemStack.getItem() instanceof ItemTool) {
				ItemTool sword = (ItemTool) itemStack.getItem();
				
				float damage = sword.getToolMaterial().getDamageVsEntity();
				
				if(GGEZ.instance.settingsManager.getSettingByName("PreferSwords").getValBoolean())
					damage -= 1.0f;
				
				if(bestSwordDamage < damage) {
					bestSwordDamage = damage;
					bestSwordSlot = i;
				}
			}
		}
		for(int i = 0; i < allItems.length; i++) {
			List<Integer> allItem = allItems[i];
			int finalI = i;
			allItem.stream().filter(slot -> slot != bestArmorSlots[finalI]).forEach(trash::add);
		}
		allSwords.stream().filter(slot -> slot != bestSwordSlot).forEach(trash::add);
	}

}
