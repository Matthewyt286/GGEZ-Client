package me.GGEZ.module.render;

import de.Hero.settings.Setting;
import me.GGEZ.DumbVar;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class Hud extends Module{

	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("Enable Hud", this, true));
		GGEZ.instance.settingsManager.rSetting(new Setting("Hud Rainbow", this, true));
		GGEZ.instance.settingsManager.rSetting(new Setting("Hud Rect", this, true));
	}
	
	public Hud() {
		super("Hud", 0, Category.RENDER);
	}
	
	public void onEnable() {
		GGEZ.instance.hud.drawHud();
		if(GGEZ.instance.settingsManager.getSettingByName("Hud Rainbow").getValBoolean()) {
			DumbVar.HudColor = 1;
		}else {
			DumbVar.HudColor = 2;
		}
		if(GGEZ.instance.settingsManager.getSettingByName("Hud Rect").getValBoolean()) {
			DumbVar.HudRect = 1;
		}else {
			DumbVar.HudRect = 0;
		}
		if(GGEZ.instance.settingsManager.getSettingByName("Enable Hud").getValBoolean()) {
			DumbVar.Hud = 1;
		}else {
			DumbVar.Hud = 0;
		}
		toggle();
	}
	
	public void onDisable() {
	}

}
