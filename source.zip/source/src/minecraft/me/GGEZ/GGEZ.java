package me.GGEZ;

import org.lwjgl.opengl.Display;

import Alt.AltManager;
import de.Hero.clickgui.ClickGUI;
import de.Hero.settings.SettingsManager;
import me.GGEZ.module.ModuleManager;
import me.GGEZ.module.render.TabGui;
import me.GGEZ.ui.HUD;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;

public class GGEZ {
	
	public static String name = "GGEZ", buildVersion = "v1", buildVersionInt = "1", mcVersion = "1.8", creator = "Matthew286";
	public static GGEZ instance = new GGEZ();
	public static SettingsManager settingsManager;
	public static ModuleManager moduleManager;
	public static ClickGUI clickGUI;
	public static AltManager altManager;
	public static TabGui TabGuiHud;
	public static HUD hud = new HUD();
	
	public static void startClient() {
		settingsManager = new SettingsManager();
		moduleManager = new ModuleManager();
		clickGUI = new ClickGUI();
		altManager = new AltManager();
		TabGuiHud = new TabGui();
		
		Display.setTitle(name + " " + buildVersion + " " + mcVersion);
	}

	
}
