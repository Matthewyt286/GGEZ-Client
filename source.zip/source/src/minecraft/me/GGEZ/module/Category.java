package me.GGEZ.module;

public enum Category {
	
	COMBAT("Combat"),
	MOVEMENT("Movement"),
	PLAYER("Player"),
	RENDER("Render"),
	EXPLOIT("Exploit"),
	FUN("Fun"),
	GHOST("Ghost"),
	UTILITY("Utility"),
	MISC("Misc");
	
	public String name;
	public int moduleIndex;
	
	Category(String name) {
		this.name = name;
	}

}
