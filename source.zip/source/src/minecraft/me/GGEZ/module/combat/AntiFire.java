package me.GGEZ.module.combat;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

import net.minecraft.network.play.client.C03PacketPlayer;

public class AntiFire extends Module{

	public AntiFire() {
		super("AntiFire", Keyboard.KEY_U, Category.COMBAT);
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			if(mc.thePlayer.isBurning() && !mc.thePlayer.capabilities.isCreativeMode && mc.thePlayer.onGround) {
				for(int i = 0; i < 100; i++) {
					mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer());
				}
			}
		}
	}

}
