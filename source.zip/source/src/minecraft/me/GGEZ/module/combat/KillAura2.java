package me.GGEZ.module.combat;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.DumbVar;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.AuraUtil;
import me.GGEZ.utils.RotationUtil;
import me.GGEZ.utils.TimeUtil;
import me.GGEZ.utils.Wrapper;
import net.minecraft.entity.EntityLivingBase;

public class KillAura2 extends Module {

	public KillAura2() {
		super("KillAura", Keyboard.KEY_R, Category.COMBAT);
	}
	
	@Override
	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("AuraRange", this, 4, 3, 6, false));
		GGEZ.instance.settingsManager.rSetting(new Setting("AuraAPS", this, 13, 1, 20, true));
		GGEZ.instance.settingsManager.rSetting(new Setting("Show Attacking", this, false));
	}
	
	public static float yaw, pitch;
	public EntityLivingBase target;
	private final TimeUtil timeUtil = new TimeUtil();

	@Override
	@SuppressWarnings("unused")
	public void onUpdate() {
		onPreUpdate();
		target = AuraUtil.getTarget(GGEZ.instance.settingsManager.getSettingByName("AuraRange").getValDouble());
		
		if(target == null || !this.isToggled())
			return;
		
		float[] rotations = RotationUtil.getRotations(target);
		yaw = rotations[0];
		pitch = rotations[1];
		
		if(timeUtil.hasTimePassed((long) (1000 / GGEZ.instance.settingsManager.getSettingByName("AuraRange").getValDouble()))) {
			AuraUtil.attack(target);
			if(GGEZ.instance.settingsManager.getSettingByName("Show Attacking").getValBoolean()) {
				GGEZ.instance.moduleManager.addChatMessage("ATTACKING: " + target.getName() + ", HEALTH: " + target.getHealth() + "/" + target.getMaxHealth());
			}
			timeUtil.reset();
		}
	}
	
	private void onPreUpdate() {
		if(target == null || !this.isToggled())
			return;
		
		mc.thePlayer.rotationYawHead = yaw;
		mc.thePlayer.renderYawOffset = yaw;
	}

	@Override
	public void onEnable() {
		DumbVar.fakeNoSlow = 1;
		super.onEnable();
		yaw = mc.thePlayer.rotationYaw;
		pitch = mc.thePlayer.rotationPitch;
		target = null;
	}

	@Override
	public void onDisable() {
		DumbVar.fakeNoSlow = 0;
		super.onDisable();
	}

}
