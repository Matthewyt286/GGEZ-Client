package me.GGEZ.module.combat;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class Velocity2 extends Module {

	public void setup() {
		GGEZ.instance.settingsManager.rSetting(new Setting("Horizontal", this, 90, 0, 100, true));
		GGEZ.instance.settingsManager.rSetting(new Setting("Vertical", this, 100, 0, 100, true));
	}

	public Velocity2() {
		super("Velocity2", 0, Category.COMBAT);
	}

	public void onUpdate() {
		float horizontal = (float) GGEZ.instance.settingsManager.getSettingByName("Horizontal").getValDouble();
		float vertical = (float) GGEZ.instance.settingsManager.getSettingByName("Vertical").getValDouble();

		if (!this.isToggled())
			return;

			if (this.isToggled()) {
				mc.thePlayer.motionX *= (float) horizontal / 100;
				mc.thePlayer.motionY *= (float) vertical / 100;
				mc.thePlayer.motionZ *= (float) horizontal / 100;
			}

	}

}
