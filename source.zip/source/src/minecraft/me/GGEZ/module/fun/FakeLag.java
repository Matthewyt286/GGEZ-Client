package me.GGEZ.module.fun;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class FakeLag extends Module{

	public FakeLag() {
		super("FakeLag", 0, Category.FUN);
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			double x1 = Math.random() * 0.2;
			double y1 = Math.random() * 0.2;
			double z1 = Math.random() * 0.2;
			
			double x2 = Math.random() * 0.2;
			double y2 = Math.random() * 0.2;
			double z2 = Math.random() * 0.2;
			
			double rand = Math.random() * 2;
			
			this.mc.thePlayer.setPosition(this.mc.thePlayer.lastTickPosX - x1, this.mc.thePlayer.lastTickPosY - y1, this.mc.thePlayer.lastTickPosZ - z1);
			this.mc.thePlayer.setPosition(this.mc.thePlayer.posX + x2, this.mc.thePlayer.posY + y2, this.mc.thePlayer.posZ + z2);
			
			this.mc.thePlayer.cameraPitch = (float) (this.mc.thePlayer.prevCameraPitch + x1 - x2);
			this.mc.thePlayer.cameraYaw = (float) (this.mc.thePlayer.prevCameraYaw + y1 - y2);
			
			this.mc.thePlayer.fallDistance = 10;
			
			
			if(rand == 1)
				net.minecraft.util.Timer.timerSpeed = 1F;
			if(rand == 2)
				net.minecraft.util.Timer.timerSpeed = 0.53F;
		}
	}

}
