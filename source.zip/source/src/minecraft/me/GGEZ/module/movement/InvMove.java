package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;

public class InvMove extends Module{

	public InvMove() {
		super("InvMove", 0, Category.MOVEMENT);
	}
	
	@Override
	public void onUpdate() {
		if(!this.isToggled())
			return;
		
		if (mc.currentScreen == null || mc.currentScreen instanceof GuiChat)
			return;

		KeyBinding[] movebinds = { mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack, mc.gameSettings.keyBindLeft,
		                           mc.gameSettings.keyBindRight, mc.gameSettings.keyBindJump
		                         };

		for (KeyBinding kb : movebinds)
			KeyBinding.setKeyBindState(kb.getKeyCode(), Keyboard.isKeyDown(kb.getKeyCode()));

		if (Keyboard.isKeyDown(Keyboard.KEY_UP))
			player().rotationPitch -= 2;

		if (Keyboard.isKeyDown(Keyboard.KEY_DOWN))
			player().rotationPitch += 2;

		if (Keyboard.isKeyDown(Keyboard.KEY_LEFT))
			player().rotationYaw -= 2;

		if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT))
			player().rotationYaw += 2;
	}

}
