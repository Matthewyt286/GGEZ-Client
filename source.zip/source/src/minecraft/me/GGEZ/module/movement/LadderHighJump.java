package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.Invoker;

public class LadderHighJump extends Module{

	private int ticks = 0;
	
	public LadderHighJump() {
		super("LadderHighJump", Keyboard.KEY_F7, Category.MOVEMENT);
	}
	
	@Override
	public void onUpdate() {
		if(this.isToggled()) {
			ticks++;
			if(Invoker.isOnLadder() && Keyboard.isKeyDown(Invoker.getForwardCode())) {
				Invoker.setMotionY(1);
			}else if(Invoker.isOnLadder() && !Keyboard.isKeyDown(Invoker.getForwardCode())) {
				Invoker.setMotionY(-1);
			}
		}
	}

}
