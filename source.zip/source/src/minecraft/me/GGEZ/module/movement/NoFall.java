package me.GGEZ.module.movement;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

import net.minecraft.network.play.client.C03PacketPlayer;

public class NoFall extends Module{
	
	public NoFall() {
		super("NoFall", Keyboard.KEY_N, Category.MOVEMENT);
	}
	
	public void onUpdate() {
		if(this.isToggled()) {
			if(mc.thePlayer.fallDistance > 2f) {
				mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
			}
			super.onUpdate();
		}
	}

}
