package me.GGEZ.module.movement;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.notifications.Notification;
import me.GGEZ.notifications.NotificationManager;
import me.GGEZ.notifications.NotificationType;

public class Speed extends Module{

	
	public Speed() {
		super("Speed", Keyboard.KEY_X, Category.MOVEMENT);
	}
	
	private double speed = GGEZ.instance.settingsManager.getSettingByName("Run Speed").getValDouble();
	
	public void setup() {
		ArrayList<String> options = new ArrayList<>();
		options.add("Run Speed");
		GGEZ.instance.settingsManager.rSetting(new Setting("Run Speed", this, speed, 1, 20, false));
		GGEZ.instance.settingsManager.rSetting(new Setting("NoLimit", this, false));
		
	}
	
	public void onEnable() {
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("NoLimit").getValBoolean()) {
			NotificationManager.show(new Notification(NotificationType.INFO, "speed", "you will go very fast even you ju", 1));
		}
	}
	
	public void onUpdate() {
		if(this.isToggled()) {
			for(int i = 0; i < GGEZ.instance.settingsManager.getSettingByName("Run Speed").getValDouble(); i++) {
				if(mc.thePlayer.onGround) {
					mc.thePlayer.motionX *= 1.1f;
					mc.thePlayer.motionZ *= 1.1f;
				}
			}
		}
		
		if(this.isToggled() && GGEZ.instance.settingsManager.getSettingByName("NoLimit").getValBoolean()) {
			mc.thePlayer.motionX *= 2.0f;
			mc.thePlayer.motionZ *= 2.0f;
		}
		
	
	}
}
