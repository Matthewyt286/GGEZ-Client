package me.GGEZ.module.utility;

import java.util.ArrayList;

import de.Hero.settings.Setting;
import me.GGEZ.GGEZ;
import me.GGEZ.module.Category;
import me.GGEZ.module.Module;
import me.GGEZ.utils.Util;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C07PacketPlayerDigging.Action;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class BedNuker extends Module{

	private double Range = GGEZ.instance.settingsManager.getSettingByName("Range").getValDouble();
	
	public void setup() {
		ArrayList<String> options = new ArrayList<>();
		options.add("Range");
		GGEZ.instance.settingsManager.rSetting(new Setting("Range", this, Range, 1, 20, false));
	}
	
	public BedNuker() {
		super("BedNuker", 0, Category.UTILITY);
	}
	
	@Override
	public void onUpdate() {
		BlockPos[] bps = Util.getBlocksAround(player(), Range, false);
		for (final BlockPos bp : bps)
			if (world().getBlock(bp).getUnlocalizedName().equals("tile.bed"))
				new Thread(new Runnable() {
				public void run() {
					sendPacket(new C07PacketPlayerDigging(Action.START_DESTROY_BLOCK, bp, EnumFacing.UP));
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					sendPacket(new C07PacketPlayerDigging(Action.STOP_DESTROY_BLOCK, bp, EnumFacing.UP));
				}
			}).start();
	}

}
