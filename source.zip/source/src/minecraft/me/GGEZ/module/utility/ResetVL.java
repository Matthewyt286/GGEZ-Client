package me.GGEZ.module.utility;

import org.lwjgl.input.Keyboard;

import me.GGEZ.module.Category;
import me.GGEZ.module.Module;

public class ResetVL extends Module{

	public ResetVL() {
		super("ResetVL", Keyboard.KEY_F12, Category.UTILITY);
	}
	
	public void onEnable() {
		this.mc.thePlayer.setPosition(this.mc.thePlayer.lastTickPosX - 0.3, this.mc.thePlayer.lastTickPosY - 0.3, this.mc.thePlayer.lastTickPosZ - 0.3);
		this.mc.thePlayer.setPosition(this.mc.thePlayer.posX + 0.3, this.mc.thePlayer.posY + 0.3, this.mc.thePlayer.posZ + 0.3);
		toggle();
	}

}
