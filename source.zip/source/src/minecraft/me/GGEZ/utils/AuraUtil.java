package me.GGEZ.utils;

import java.util.Iterator;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;

public class AuraUtil {

	public static EntityLivingBase getTarget(double range) {
		
		EntityLivingBase entityLivingBase = null;
		
		for (Iterator<Entity> entity = Minecraft.getMinecraft().theWorld.loadedEntityList.iterator(); entity
				.hasNext();) {
			Object theObject = entity.next();
			if (theObject instanceof EntityLivingBase) {
				EntityLivingBase target = (EntityLivingBase) theObject;

				if (entity instanceof EntityPlayerSP)
					continue;
				
				if (Minecraft.getMinecraft().thePlayer.getDistanceToEntity(target) <= range && shouldAttack((EntityLivingBase)target)) {
					range = Minecraft.getMinecraft().thePlayer.getDistanceToEntity(target);
					entityLivingBase = (EntityLivingBase) target;
				}
			}
		}
		return entityLivingBase;
	}
	
	public static boolean shouldAttack(EntityLivingBase target) {
		return target != Minecraft.getMinecraft().thePlayer && target.isEntityAlive();
//		 && Minecraft.getMinecraft().thePlayer.canEntityBeSeen(target)
	}
	
	public static void attack(EntityLivingBase target) {
//		Minecraft.getMinecraft().getNetHandler().addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
		Minecraft.getMinecraft().thePlayer.swingItem();
		Minecraft.getMinecraft().playerController.attackEntity(Minecraft.getMinecraft().thePlayer, target);
	}

}
